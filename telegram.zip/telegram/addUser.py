from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import os
import time
import sys 

service = webdriver.chrome.service.Service('./chromedriver')
service.start()
options = webdriver.ChromeOptions()
options.add_argument('--headless')
options = options.to_capabilities()
browser = webdriver.Remote(service.service_url, options)

browser.get('http://www.facebook.com')
assert 'Facebook' in browser.title

notLoggedIn = browser.find_element_by_name('firstname')  # Find the search box


if(notLoggedIn):
	elem = browser.find_element_by_name('email')  # Find the search box
	elem.send_keys('muhammedsblackflames@hotmail.com')


	elem = browser.find_element_by_name('pass')  # Find the search box
	elem.send_keys('phpechoIloveHadi247' + Keys.RETURN)

	time.sleep(15)

	#elem = browser.find_element_by_css_selector('a.layerCancel')
	#if(elem):
	#	elem.click()

	time.sleep(15)
	## add user

	browser.get('https://www.facebook.com/groups/wingedwireless/?ref=bookmarks')

	elem = browser.find_element_by_name('freeform')  # Find the search box
	elem.send_keys(sys.argv[1] + Keys.RETURN)
	
	time.sleep(60)
	browser.quit()
else :
	time.sleep(10)
	## add user
	browser.get('https://www.facebook.com/groups/wingedwireless/?ref=bookmarks')

	elem = browser.find_element_by_name('freeform')  # Find the search box
	elem.send_keys('thejobemuhammed@gmail.com' + Keys.RETURN)
	time.sleep(60)
	browser.quit()
