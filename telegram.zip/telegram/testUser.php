<?php 
echo shell_exec('python testUser.py');

?>
