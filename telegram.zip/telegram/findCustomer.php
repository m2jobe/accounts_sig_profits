<?php
require 'vendor/autoload.php';
$email = htmlspecialchars($_GET["email"]) ;

$last_customer = NULL;
$email = $email;
\Stripe\Stripe::setApiKey("rk_live_gPxfDcylJPdYxMR9UV24lfCY");




function getCustomerByEmailAddressAndDates($emailAddress, $dateGreaterThanOrEqual, $dateLessThanOrEqual) {
    $customersResults = \Stripe\Customer::all(['created' => ['gte' => $dateGreaterThanOrEqual, 'lte' => $dateLessThanOrEqual]]);
    $customers = $customersResults->data;
    $filteredResults = [];
    foreach ($customers as $customer) {
        if ($emailAddress === $customer->email) {
            $filteredResults[] = $customer;
        }
    }
    return json_encode($filteredResults);
}

print_r(getCustomerByEmailAddressAndDates($email, strtotime('-100 day'), strtotime('-0 day')))


?>
