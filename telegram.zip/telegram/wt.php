<?php

$string = "/start muhammedjobe.com";

echo trim(substr($string, 6, strlen($string)))

?>

