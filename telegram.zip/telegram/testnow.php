<?php
echo phpinfo()
?>
